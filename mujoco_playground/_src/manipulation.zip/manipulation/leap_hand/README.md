# LEAP Hand environments

## Hardware

* [Dynamixel XL330-M288-T](https://emanual.robotis.com/docs/en/dxl/x/xl330-m288/)
* [PD gain table](https://emanual.robotis.com/docs/en/dxl/x/xc330-m288/#position-pid-gain80-82-84)
